# TheZenithVisions Backend API

Node.js + AWS Lambda backend for TheZenithVisions contact form and data management.

## 🚀 Quick Start

### 1. Install Dependencies

```bash
npm install
npm install -g serverless
```

### 2. Configure AWS CLI

```bash
aws configure
# Enter your AWS credentials
```

### 3. Verify SES Email

```bash
aws ses verify-email-identity --email-address info@thezenithvisions.com
```

Check your email and click the verification link.

### 4. Deploy

```bash
# Deploy to dev environment
npm run deploy:dev

# Deploy to production
npm run deploy:prod
```

You'll get API endpoints like:
```
POST - https://abc123.execute-api.us-east-1.amazonaws.com/dev/contact
GET  - https://abc123.execute-api.us-east-1.amazonaws.com/dev/submissions
```

## 📋 API Endpoints

### POST /contact

Submit a contact form.

**Request:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "1234567890",
  "company": "Example Corp",
  "service": "Architecture BIM",
  "message": "Interested in your services"
}
```

**Response:**
```json
{
  "message": "Form submitted successfully",
  "submissionId": "uuid-here"
}
```

### GET /submissions

Get all form submissions (admin only).

**Response:**
```json
{
  "submissions": [...],
  "count": 10
}
```

## 🧪 Testing

### Test with cURL

```bash
curl -X POST \
  https://YOUR-API-URL/dev/contact \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "message": "Test message"
  }'
```

## 📊 What's Deployed

- ✅ Lambda functions for contact form
- ✅ DynamoDB table for submissions
- ✅ API Gateway endpoints
- ✅ SES email integration
- ✅ CORS enabled

## 💰 Cost

Estimated $0-5/month for starting traffic (AWS Free Tier included).

## 🔧 Configuration

Edit `serverless.yml` to customize:
- Region
- Email addresses
- Function timeouts
- Database settings

## 📝 Logs

```bash
# View logs
npm run logs

# Or specific function
serverless logs -f submitContact -t
```

## 🗑️ Remove

```bash
npm run remove
```

## 🆘 Common Issues

### SES Sandbox Mode

By default, SES is in sandbox and can only send to verified emails.

**Solution:** Request production access in AWS Console → SES → Account Dashboard

### Lambda Timeout

If functions timeout, increase in `serverless.yml`:
```yaml
functions:
  submitContact:
    timeout: 30  # seconds
```

## 📚 Next Steps

1. Add authentication (Supabase)
2. Create admin dashboard
3. Add project quotation system
4. Implement file uploads

## 🔗 Resources

- [Serverless Framework Docs](https://www.serverless.com/framework/docs)
- [AWS Lambda Docs](https://docs.aws.amazon.com/lambda/)
- [DynamoDB Docs](https://docs.aws.amazon.com/dynamodb/)
